package com.example.google_keep_note_clone

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
